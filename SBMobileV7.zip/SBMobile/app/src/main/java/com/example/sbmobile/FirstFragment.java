package com.example.sbmobile;

import android.content.Intent;
import android.os.Bundle;
import androidx.fragment.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

public class FirstFragment extends Fragment {

    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";
    private String mParam1;
    private String mParam2;

    public FirstFragment() {
        // Constructor vacío requerido
    }

    public static FirstFragment newInstance(String param1, String param2) {
        FirstFragment fragment = new FirstFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_first, container, false);

        // Configurar el OnClickListener para el botón de emergencias principales
        Button buttonAlert = view.findViewById(R.id.EmergenciasPrincipales);
        buttonAlert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                irAlerta();
            }
        });

        // Configurar el OnClickListener para el botón de llamada al serenazgo
        Button buttonSerenazgo = view.findViewById(R.id.serenazgoEmergencyButton);
        buttonSerenazgo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Implementar la lógica para la llamada al serenazgo aquí
            }
        });

        // Configurar el OnClickListener para el botón de enviar alerta/mensaje de ayuda
        Button buttonSendAlert = view.findViewById(R.id.sendAlertButton);
        buttonSendAlert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Implementar la lógica para enviar un mensaje de alerta aquí
            }
        });

        return view;
    }

    public void irAlerta() {
        Intent miIntent = new Intent(getActivity(), Alerta.class);
        startActivity(miIntent);
    }
}
